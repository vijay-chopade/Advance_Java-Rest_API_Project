package com.example.project_lecture_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLectureApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLectureApiApplication.class, args);
	}

}
